//PRIMERA VENTANA EMERGENTE
function abrirVentana1() {
  document.getElementById('ventana1').style.display = 'block';
}

function cerrarVentana1() {
  document.getElementById('ventana1').style.display = 'none';
}


//SEGUNDA VENTA EMERGENTE
function abrirVentana2() {
  document.getElementById('ventana2').style.display = 'block';
}

function cerrarVentana2() {
  document.getElementById('ventana2').style.display = 'none';
}


//TERCERA VENTA EMERGENTE
function abrirVentana3() {
  document.getElementById('ventana3').style.display = 'block';
}

function cerrarVentana3() {
  document.getElementById('ventana3').style.display = 'none';
}


//CUARTA VENTA EMERGENTE
function abrirVentana4() {
  document.getElementById('ventana4').style.display = 'block';
}

function cerrarVentana4() {
  document.getElementById('ventana4').style.display = 'none';
}


//QUINTA VENTA EMERGENTE
function abrirVentana5() {
  document.getElementById('ventana5').style.display = 'block';
}

function cerrarVentana5() {
  document.getElementById('ventana5').style.display = 'none';
}



//SEXTA VENTANA EMERGENTE
function abrirVentana6() {
  document.getElementById('ventana6').style.display = 'block';
}

function cerrarVentana6() {
  document.getElementById('ventana6').style.display = 'none';
}


//SÉPTIMA VENTANA EMERGENTE
function abrirVentana7() {
  document.getElementById('ventana7').style.display = 'block';
}

function cerrarVentana7() {
  document.getElementById('ventana7').style.display = 'none';
}


//OCTAVA VENTANA EMERGENTE
function abrirVentana8() {
  document.getElementById('ventana8').style.display = 'block';
}

function cerrarVentana8() {
  document.getElementById('ventana8').style.display = 'none';
}


//NOVENA VENTANA EMERGENTE
function abrirVentana9() {
  document.getElementById('ventana9').style.display = 'block';
}

function cerrarVentana9() {
  document.getElementById('ventana9').style.display = 'none';
}



//DÉCIMA VENTANA EMERGENTE
function abrirVentana10() {
  document.getElementById('ventana10').style.display = 'block';
}

function cerrarVentana10() {
  document.getElementById('ventana10').style.display = 'none';
}


//UNDÉCIMA VENTANA EMERGENTE
function abrirVentana11() {
  document.getElementById('ventana11').style.display = 'block';
}

function cerrarVentana11() {
  document.getElementById('ventana11').style.display = 'none';
}


//DUODÉCIMA VENTANA EMERGENTE
function abrirVentana12() {
  document.getElementById('ventana12').style.display = 'block';
}

function cerrarVentana12() {
  document.getElementById('ventana12').style.display = 'none';
}


//TRIDÉCIMA VENTANA EMERGENTE
function abrirVentana13() {
  document.getElementById('ventana13').style.display = 'block';
}

function cerrarVentana13() {
  document.getElementById('ventana13').style.display = 'none';
}

//CUATRIDÉCIMA VENTANA EMERGENTE
function abrirVentana14() {
  document.getElementById('ventana14').style.display = 'block';
}

function cerrarVentana14() {
  document.getElementById('ventana14').style.display = 'none';
}

//VENTANA EMERGENTE QUINCE
function abrirVentana15() {
  document.getElementById('ventana15').style.display = 'block';
}

function cerrarVentana15() {
  document.getElementById('ventana15').style.display = 'none';
}